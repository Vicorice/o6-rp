/* CEM-Shader. DartCat25
*  Fragment functional (set right before main function)
*  #moj_import <cem/frag_funcs.glsl>
*/ 

//Able ins and necessary uniforms
in vec4 cem_pos1, cem_pos2, cem_pos3, cem_pos4;
in vec3 cem_uv1, cem_uv2;
in vec3 cem_glPos;
flat in int cem;
flat in int cem_reverse;

#define MAX_DEPTH 1000000

// Macros must stay on one line: GLSL 330 (as compiled by the Vulkan backend) rejects '\' line continuations.
#define ADD_SQUARE(p1, p2, p3, uv) { color = sSquare(-center, dirTBN, p1 * modelSize, p2 * modelSize, p3 * modelSize, vertexColor, color, minT, uv); }

#define ADD_BOX(pos, size, dSide, uSide, nSide, eSide, sSide, wSide) { color = sBox(-center + (pos + modelOffset) * modelSize, dirTBN, size * modelSize, lightTBN, color, minT, uSide, dSide, nSide, wSide, sSide, eSide); }

// Z is negated on center and dir to flip front/back so Blockbench's +Z north faces forward
#define ADD_BOX_ROTATE(pos, size, Rotation, rotPivot, dSide, uSide, nSide, eSide, sSide, wSide) { vec3 _ro = vec3(-center.x, -center.y, center.z) + ((pos + modelOffset) + rotPivot) * modelSize; vec3 _rd = vec3(dirTBN.x, dirTBN.y, -dirTBN.z); color = sBox(Rotation * _ro - rotPivot * modelSize, Rotation * _rd, size * modelSize, lightTBN * inverse(Rotation), color, minT, uSide, dSide, nSide, wSide, sSide, eSide); }

// Like ADD_BOX_ROTATE, but the box follows the hips/body instead of the leg carrying it: the view ray is rotated
// about the hip joint (hipPivot, in the same divided units as pos) by hipsRot, which cancels the leg's swing.
#define ADD_BOX_HIPS(pos, size, Rotation, rotPivot, hipPivot, dSide, uSide, nSide, eSide, sSide, wSide) { vec3 _pv = -(hipPivot + modelOffset) * modelSize; vec3 _cam = vec3(-center.x, -center.y, center.z); vec3 _ro = _pv + hipsRot * (_cam - _pv) + ((pos + modelOffset) + rotPivot) * modelSize; vec3 _rd = hipsRot * vec3(dirTBN.x, dirTBN.y, -dirTBN.z); color = sBox(Rotation * _ro - rotPivot * modelSize, Rotation * _rd, size * modelSize, hipsLightTBN * inverse(Rotation), color, minT, uSide, dSide, nSide, wSide, sSide, eSide); }

#define ADD_QUAD(p1, p2, p3, p4, uv) { }

//Got from https://iquilezles.org/articles/intersectors/
vec3 squareIntersect( in vec3 ro, in vec3 rd, in vec3 v0, in vec3 v1, in vec3 v2 )
{
    vec3 v1v0 = v1 - v0;
    vec3 v2v0 = v2 - v0;
    vec3 rov0 = ro - v0;
    vec3  n = cross( v1v0, v2v0 );
    vec3  q = cross( rov0, rd );
    float d = 1.0/dot( rd, n );
    float u = d*dot( -q, v2v0 );
    float v = d*dot(  q, v1v0 );
    float t = d*dot( -n, rov0 );
    if(u<0.0 || v<0.0 || u > 1.0 || v > 1.0 || t < 0) t = MAX_DEPTH;
    return vec3( u, v, t );
}

vec3 triIntersect( in vec3 ro, in vec3 rd, in vec3 v0, in vec3 v1, in vec3 v2 )
{
    vec3 v1v0 = v1 - v0;
    vec3 v2v0 = v2 - v0;
    vec3 rov0 = ro - v0;
    vec3  n = cross( v1v0, v2v0 );
    vec3  q = cross( rov0, rd );
    float d = 1.0/dot( rd, n );
    float u = d*dot( -q, v2v0 );
    float v = d*dot(  q, v1v0 );
    float t = d*dot( -n, rov0 );
    if(u<0.0 || v<0.0 || t < 0 || u + v > 1.0) t = MAX_DEPTH;
    return vec3( u, v, t );
}

// 0..1 coordinates of a point on the box surface, within the face with the given outward normal.
vec2 boxFaceUV(vec3 pos, vec3 size, vec3 normal)
{
    vec3 p = pos / size;
    vec2 tex = vec2(0);
    if (abs(normal.x) > 0.9)
        tex = vec2(p.z, -p.y);
    else if (abs(normal.y) > 0.9)
        tex = p.xz;
    else if (abs(normal.z) > 0.9)
        tex = p.xy;

    return clamp(tex / 2 + 0.5, vec2(0), vec2(1));
}

// 26.2 uses a [0, 1] clip-space depth range (glClipControl ZERO_TO_ONE / Vulkan), so NDC z is already window depth.
void writeDepth(vec3 Pos)
{
    vec4 ProjPos = ProjMat * vec4(Pos, 1);
    gl_FragDepth = ProjPos.z / ProjPos.w;
}

vec4 sSquare(vec3 ro, vec3 rd, vec3 p1, vec3 p2, vec3 p3, vec4 tint, vec4 color, inout float T, vec4 uv)
{
    vec3 tris = squareIntersect(ro, rd, p1, p2, p3);

    if (tris.z >= T) return color;

    vec4 col = texelFetch(Sampler0, ivec2(uv.xy + uv.zw * tris.xy), 0) * tint;
    
    if (col.a < 0.1) return color;

    T = tris.z;
    return col;
}

vec4 sTris(vec3 ro, vec3 rd, vec3 p1, vec3 p2, vec3 p3, vec4 color, inout float T, vec4 uv)
{
    vec3 tris = triIntersect(ro, rd, p1, p2, p3);

    if (tris.z >= T) return color;

    vec4 col = texelFetch(Sampler0, ivec2(uv.xy + uv.zw * tris.xy), 0);
    
    if (col.a < 0.1) return color;

    T = tris.z;
    return col;
}

vec4 sQuad(vec3 ro, vec3 rd, float modelSize, vec3 p1, vec3 p2, vec3 p3, vec3 p4, vec4 color, inout float T, vec4 uv)
{
    color = sTris(ro, rd, p1 * modelSize, p2 * modelSize, p3 * modelSize, color, T, uv);
    color = sTris(ro, rd, p4 * modelSize, p3 * modelSize, p2 * modelSize, color, T, vec4(uv.xy + uv.zw, -uv.zw));
    return color;
}

// Texture colour of one box face at the given 0..1 face coordinates; vec4(0) if the face has no texture.
vec4 boxFaceColor(vec3 normal, vec2 box, vec2 texSize, vec4 dSide, vec4 uSide, vec4 nSide, vec4 eSide, vec4 sSide, vec4 wSide)
{
    if (normal.x > 0.9 && eSide != vec4(0)) //East
        return texture(Sampler0, (eSide.xy + eSide.zw * vec2(1.0 -box.x, 1.0 -box.y)) / texSize);
    if (normal.x < -0.9 && wSide != vec4(0)) //West
        return texture(Sampler0, (wSide.xy + wSide.zw * vec2(box.x, 1.0 -box.y)) / texSize);
    if (normal.z > 0.9 && nSide != vec4(0)) //South
        return texture(Sampler0, (nSide.xy + nSide.zw * vec2(box.x, box.y)) / texSize);
    if (normal.z < -0.9 && sSide != vec4(0)) //North
        return texture(Sampler0, (sSide.xy + sSide.zw * vec2(1.0 -box.x, box.y)) / texSize);
    if (normal.y > 0.9 && uSide != vec4(0)) //Up
        return texture(Sampler0, (uSide.xy + uSide.zw * vec2(1.0-box.x, box.y)) / texSize);
    if (normal.y < -0.9 && dSide != vec4(0)) //Down
        return texture(Sampler0, (dSide.xy + dSide.zw * vec2(1.0 -box.x,1.0 - box.y)) / texSize);
    return vec4(0);
}

vec4 litBoxColor(vec4 col, mat3 TBN, vec3 normal)
{
#ifdef CEM_LIGHTING
    col = minecraft_mix_light(Light0_Direction, Light1_Direction, normalize(TBN * normal), col);
#endif
    return col;
}

// Ray-traces a box. If the face the ray enters through is untextured or transparent there,
// the face it exits through is shown from behind, so a face with no texture on its opposite
// side (e.g. a flat plane) shows the back of the textured face instead of disappearing.
vec4 sBox(vec3 ro, vec3 rd, vec3 size, mat3 TBN, vec4 color, inout float T, vec4 dSide, vec4 uSide, vec4 nSide, vec4 eSide, vec4 sSide, vec4 wSide)
{
    vec2 texSize = textureSize(Sampler0, 0);

    vec3 m = 1.0 / rd;
    vec3 n = m * ro;
    vec3 k = abs(m) * size;
    vec3 t1 = -n - k;
    vec3 t2 = -n + k;
    float tN = max( max( t1.x, t1.y ), t1.z );
    float tF = min( min( t2.x, t2.y ), t2.z );
    if (tN > tF || tF < 0.0)
        return color;

    // Entry face: seen from the front.
    if (tN > 0.0 && tN < T)
    {
        vec3 normalN = -sign(rd) * step(t1.yzx, t1.xyz) * step(t1.zxy, t1.xyz);
        vec4 col = boxFaceColor(normalN, boxFaceUV(ro + rd * tN, size, normalN), texSize, dSide, uSide, nSide, eSide, sSide, wSide);
        col = litBoxColor(col, TBN, normalN);
        if (col.a >= 0.1)
        {
            T = tN;
            return col;
        }
    }

    // Exit face: seen from behind, lit as if facing the viewer.
    if (tF < T)
    {
        vec3 normalF = sign(rd) * step(t2.xyz, t2.yzx) * step(t2.xyz, t2.zxy);
        vec4 col = boxFaceColor(normalF, boxFaceUV(ro + rd * tF, size, normalF), texSize, dSide, uSide, nSide, eSide, sSide, wSide);
        col = litBoxColor(col, TBN, -normalF);
        if (col.a >= 0.1)
        {
            T = tF;
            return col;
        }
    }

    return color;
}
// glsl-armor-shaders v9
